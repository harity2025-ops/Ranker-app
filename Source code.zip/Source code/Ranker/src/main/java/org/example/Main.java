package org.example;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main extends JFrame {
    public static Workbook workbook;
    private JLabel statusLabel;
    private JLabel iconLabel;
    private JButton importBtn;
    private File currentFile;

    public Main() {
        setTitle("📊 Ranker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 250);
        setLocationRelativeTo(null);
        setResizable(false);

        // Main panel with rounded corners and gradient
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(240, 248, 255),
                        0, getHeight(), new Color(220, 235, 255)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        mainPanel.setLayout(new BorderLayout(15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        mainPanel.setOpaque(false);

        // Top panel with icon and title
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        topPanel.setOpaque(false);

        iconLabel = new JLabel("📂");
        iconLabel.setFont(new Font("Segoe UI", Font.PLAIN, 48));

        JLabel titleLabel = new JLabel("Import Spreadsheet");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(40, 60, 90));

        topPanel.add(iconLabel);
        topPanel.add(titleLabel);

        // Center panel with button
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);

        importBtn = new JButton("📁 Select File");
        importBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        importBtn.setBackground(new Color(70, 130, 180));
        importBtn.setForeground(Color.WHITE);
        importBtn.setFocusPainted(false);
        importBtn.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        importBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // REMOVE FOCUS FROM BUTTON
        importBtn.setFocusable(false);
        importBtn.setRequestFocusEnabled(false);

        // Hover effect
        importBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                importBtn.setBackground(new Color(100, 160, 210));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                importBtn.setBackground(new Color(70, 130, 180));
            }
        });

        importBtn.addActionListener(e -> selectFile());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 0, 10, 0);
        centerPanel.add(importBtn, gbc);

        // Status panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setOpaque(false);

        statusLabel = new JLabel("💡 Click 'Select File' to import a spreadsheet");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        statusLabel.setForeground(new Color(80, 100, 120));
        bottomPanel.add(statusLabel);

        // Add all panels
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Remove focus from everything
        setFocusable(false);
        setFocusTraversalKeysEnabled(false);

        setVisible(true);
    }

    private void selectFile() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select Spreadsheet File");

        // Support both .xls and .xlsx formats
        fc.setFileFilter(new FileNameExtensionFilter(
                "Excel Files (.xls, .xlsx)", "xls", "xlsx"
        ));

        fc.addChoosableFileFilter(
                new FileNameExtensionFilter("Excel 97-2003 (.xls)", "xls")
        );

        fc.addChoosableFileFilter(
                new FileNameExtensionFilter("Excel Workbook (.xlsx)", "xlsx")
        );

        fc.setCurrentDirectory(new File(System.getProperty("user.home")));

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();

            // Update UI to show loading
            statusLabel.setText("⏳ Loading: " + file.getName() + "...");
            importBtn.setEnabled(false);
            iconLabel.setText("⏳");

            // Use SwingWorker for background loading
            SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
                @Override
                protected Boolean doInBackground() throws Exception {
                    try {
                        String fileName = file.getName().toLowerCase();
                        FileInputStream fis = new FileInputStream(file);

                        // Detect format and create appropriate workbook
                        if (fileName.endsWith(".xls")) {
                            workbook = new HSSFWorkbook(fis);
                        } else if (fileName.endsWith(".xlsx")) {
                            workbook = new XSSFWorkbook(fis);
                        } else {
                            return false;
                        }

                        fis.close();
                        return true;

                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }

                @Override
                protected void done() {
                    try {
                        boolean success = get();

                        if (success) {
                            iconLabel.setText("✅");

                            String format =
                                    workbook instanceof HSSFWorkbook ? ".xls" : ".xlsx";

                            statusLabel.setText(
                                    "✅ Loaded: " + file.getName() +
                                            " (" + workbook.getNumberOfSheets() +
                                            " sheets, " + format + ")"
                            );

                            importBtn.setText("📁 Change File");

                            // Show success notification
                            JOptionPane.showMessageDialog(
                                    Main.this,
                                    "Successfully loaded:\n" + file.getName() +
                                            "\nFormat: " + format.toUpperCase() +
                                            "\nSheets: " + workbook.getNumberOfSheets(),
                                    "Import Successful",
                                    JOptionPane.INFORMATION_MESSAGE
                            );

                            // Process workbook after loading
                            processWorkbook();

                        } else {
                            iconLabel.setText("❌");
                            statusLabel.setText("❌ Failed to load file (unsupported format)");
                            importBtn.setText("📁 Select File");
                        }

                    } catch (Exception e) {
                        iconLabel.setText("❌");
                        statusLabel.setText("❌ Error loading file");
                        importBtn.setText("📁 Select File");

                    } finally {
                        importBtn.setEnabled(true);

                        // Keep focus removed when re-enabled
                        importBtn.setFocusable(false);
                        importBtn.setRequestFocusEnabled(false);
                    }
                }
            };

            worker.execute();
            currentFile = file;
        }
    }

    private void processWorkbook() {
        if (workbook == null) {
            System.out.println("No workbook loaded!");
            return;
        }

        try {
            // importing necessary data
            Sheet sheet = workbook.getSheetAt(0);

            Row row = sheet.getRow(0);
            Cell cell = row.getCell(1);

            int number_of_student =
                    (int) cell.getNumericCellValue();

            row = sheet.getRow(1);
            cell = row.getCell(1);

            int subjects =
                    (int) cell.getNumericCellValue();

            int final_row = 4 + number_of_student;
            int base_identifier = 4 + number_of_student;

            int[] base_mark = new int[subjects];

            double[][] mark_list =
                    new double[number_of_student][subjects];


            // importing all marks
            for (int a = 4; a < final_row; a++) {

                row = sheet.getRow(a);

                for (int b = 1; b < subjects + 1; b++) {

                    cell = row.getCell(b);

                    mark_list[a - 4][b - 1] =
                            cell.getNumericCellValue();
                }
            }


            // importing base mark
            row = sheet.getRow(base_identifier);

            for (int b = 1; b < subjects + 1; b++) {

                cell = row.getCell(b);

                base_mark[b - 1] =
                        (int) cell.getNumericCellValue();
            }


            // converting mark
            int[][] marks =
                    converter(mark_list, base_mark);


            //placeing the converted mark into the file
            for (int i = 0; i < number_of_student; i++) {

                row = sheet.getRow(4 + i);

                for (int j = 0; j < subjects; j++) {

                    cell = row.getCell(j + 1);

                    if (cell == null) {
                        cell = row.createCell(j + 1);
                    }

                    // Put converted mark into the ORIGINAL cell
                    cell.setCellValue(marks[i][j]);
                }
            }


            // determining pass or fail
            boolean[][] pass_list =
                    pass_fail_chk(marks);


            // getting the total of students' average and pass or fail
            int[] total_stu =
                    new int[number_of_student];

            int[] student_average =
                    new int[number_of_student];

            boolean[] pass_stu =
                    new boolean[number_of_student];

            String[] stu_status =
                    new String[number_of_student];


            for (int i = 0; i < number_of_student; i++) {

                total_stu[i] =
                        total_mark_student(marks, i);

                student_average[i] =
                        average_student(marks, i, subjects);

                pass_stu[i] =
                        pass_in_stu(pass_list, i);

                stu_status[i] =
                        PorFword(pass_stu[i]);
            }


            // ranking
            int[] average_subject =
                    new int[subjects];

            int[] pass_num =
                    new int[subjects];


            for (int i = 0; i < subjects; i++) {

                pass_num[i] =
                        sub_pass_num(
                                pass_in_sub(pass_list, i)
                        );

                average_subject[i] =
                        average_subject(
                                pass_list,
                                marks,
                                i
                        );
            }


            String[] rankStrings =
                    new String[number_of_student];

            Arrays.fill(rankStrings, "-");


            List<Integer> passedIndices =
                    new ArrayList<>();


            for (int i = 0; i < number_of_student; i++) {

                if (pass_stu[i]) {
                    passedIndices.add(i);
                }
            }


            passedIndices.sort(
                    (i1, i2) ->
                            Integer.compare(
                                    total_stu[i2],
                                    total_stu[i1]
                            )
            );


            int idx = 0;
            int rank = 1;


            while (idx < passedIndices.size()) {

                int start = idx;

                int currentTotal =
                        total_stu[
                                passedIndices.get(idx)
                                ];


                while (
                        idx < passedIndices.size()
                                &&
                                total_stu[
                                        passedIndices.get(idx)
                                        ] == currentTotal
                ) {
                    idx++;
                }


                for (int j = start; j < idx; j++) {

                    rankStrings[
                            passedIndices.get(j)
                            ] =
                            String.valueOf(rank);
                }


                rank = idx + 1;
            }


            // writing all data
            // student
            int studentRowStart = 4;

            int totalCol =
                    subjects + 1;

            int passFailCol =
                    subjects + 2;

            int averageCol =
                    subjects + 3;

            int rankCol =
                    subjects + 4;


            for (int i = 0; i < number_of_student; i++) {

                row =
                        sheet.getRow(
                                studentRowStart + i
                        );

                if (row == null) {
                    row =
                            sheet.createRow(
                                    studentRowStart + i
                            );
                }


                // Write total
                cell =
                        row.getCell(totalCol);

                if (cell == null) {
                    cell =
                            row.createCell(totalCol);
                }

                cell.setCellValue(
                        total_stu[i]
                );


                // Write pass/fail
                cell =
                        row.getCell(passFailCol);

                if (cell == null) {
                    cell =
                            row.createCell(passFailCol);
                }

                cell.setCellValue(
                        stu_status[i]
                );


                // Write average
                cell =
                        row.getCell(averageCol);

                if (cell == null) {
                    cell =
                            row.createCell(averageCol);
                }

                cell.setCellValue(
                        student_average[i]
                );


                // Write rank
                cell =
                        row.getCell(rankCol);

                if (cell == null) {
                    cell =
                            row.createCell(rankCol);
                }

                cell.setCellValue(
                        rankStrings[i]
                );
            }


            // subject
            int basemarkRow =
                    4 + number_of_student;

            int subjectAvgRow =
                    basemarkRow + 1;

            int subjectPassRow =
                    basemarkRow + 2;


            Row avgRow =
                    sheet.getRow(subjectAvgRow);

            if (avgRow == null) {
                avgRow =
                        sheet.createRow(subjectAvgRow);
            }


            Cell avgLabel =
                    avgRow.getCell(0);

            if (avgLabel == null) {
                avgLabel =
                        avgRow.createCell(0);
            }

            avgLabel.setCellValue("average");


            Row passRow =
                    sheet.getRow(subjectPassRow);

            if (passRow == null) {
                passRow =
                        sheet.createRow(subjectPassRow);
            }


            Cell passLabel =
                    passRow.getCell(0);

            if (passLabel == null) {
                passLabel =
                        passRow.createCell(0);
            }

            passLabel.setCellValue("pass/tail");


            for (int sub = 0; sub < subjects; sub++) {

                Cell avgCell =
                        avgRow.getCell(sub + 1);

                if (avgCell == null) {
                    avgCell =
                            avgRow.createCell(sub + 1);
                }

                avgCell.setCellValue(
                        average_subject[sub]
                );


                Cell passCell =
                        passRow.getCell(sub + 1);

                if (passCell == null) {
                    passCell =
                            passRow.createCell(sub + 1);
                }

                passCell.setCellValue(
                        pass_num[sub]
                                + "/"
                                + number_of_student
                );
            }


            saveWorkbook(workbook);

        } catch (Exception e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "An Error occurred while processing file:\n"
                            + e.getClass().getSimpleName()
                            + "\n"
                            + e.getMessage(),
                    "Warning",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }


    public static void main(String[] args) {

        // Set look and feel
        try {

            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()
            );

        } catch (Exception e) {
            e.printStackTrace();
        }


        SwingUtilities.invokeLater(
                () -> new Main()
        );
    }


    public static int[][] converter(double[][] mark_list, int[] basemark) {

        int students =
                mark_list.length;

        int subjects =
                mark_list[0].length;

        int[][] marks =
                new int[students][subjects];


        for (int student = 0;
             student < students;
             student++) {

            for (int subject = 0;
                 subject < subjects;
                 subject++) {

                double percentage =
                        (
                                mark_list[student][subject]
                                        /
                                        basemark[subject]
                        ) * 100;


                marks[student][subject] =
                        (int) Math.round(percentage);
            }
        }


        return marks;
    }


    public static boolean[][] pass_fail_chk(int[][] mark_list) {

        int students =
                mark_list.length;

        int subjects =
                mark_list[0].length;

        boolean[][] pass =
                new boolean[students][subjects];


        for (int a = 0; a < students; a++) {

            for (int b = 0; b < subjects; b++) {

                if (mark_list[a][b] < 35) {

                    pass[a][b] = false;

                } else {

                    pass[a][b] = true;
                }
            }
        }


        return pass;
    }


    public static boolean[] pass_in_sub(boolean[][] pass_fail, int sub) {

        boolean[] pass =
                new boolean[pass_fail.length];

        int i = 0;


        for (boolean[] a : pass_fail) {

            pass[i] = a[sub];

            i++;
        }


        return pass;
    }


    public static boolean pass_in_stu( boolean[][] pass_fail, int stu) {
        boolean[] pass =
                pass_fail[stu];

        boolean p = true;


        for (boolean a : pass) {

            p = p & a;
        }


        return p;
    }


    public static int total_mark_student( int[][] mark_list, int student) {

        int total = 0;


        for (int mark :
                mark_list[student]) {

            total += mark;
        }


        return total;
    }


    public static int average_student(int[][] mark_list, int student, int subjects) {

        double total = 0;


        for (int subject = 0;
             subject < subjects;
             subject++) {

            total +=
                    mark_list[student][subject];
        }


        return (int) Math.round(
                total / subjects
        );
    }


    public static int average_subject(boolean[][] pass_list, int[][] mark_list, int subject) {

        int total = 0;

        int passed_students = 0;


        for (int student = 0;
             student < mark_list.length;
             student++) {

            if (pass_list[student][subject]) {

                total +=
                        mark_list[student][subject];

                passed_students++;
            }
        }


        if (passed_students == 0) {
            return 0;
        }


        return (int) Math.round(
                (double) total / passed_students
        );
    }


    private void saveWorkbook(Workbook workbook) {

        if (currentFile == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "No file to save!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }


        try (
                FileOutputStream fos =
                        new FileOutputStream(currentFile)
        ) {

            workbook.write(fos);


            JOptionPane.showMessageDialog(
                    this,
                    "Ranked successfully!\nFile updated: "
                            + currentFile.getName(),
                    "Save Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );


        } catch (Exception e) {

            e.printStackTrace();


            JOptionPane.showMessageDialog(
                    this,
                    "Could not save file:\n"
                            + e.getMessage(),
                    "Save Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }


    public static String PorFword(boolean a) {

        if (a) {
            return "Pass";
        } else {
            return "Fail";
        }
    }


    public static int sub_pass_num(boolean[] a) {

        int pass = 0;


        for (boolean b : a) {

            if (b) {
                pass++;
            }
        }


        return pass;
    }
}